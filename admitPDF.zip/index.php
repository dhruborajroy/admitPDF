<?php
date_default_timezone_set("Asia/Dhaka");
if(isset($_GET['id'])){
	$id=$_GET['id'];
}
require('vendor/autoload.php');
$con=mysqli_connect('localhost','root','','bus');
$res=mysqli_query($con,"select * from users where id=".$id);
if(mysqli_num_rows($res)>0){
	$row=mysqli_fetch_assoc($res);
	$html='<div class="border row">
		<table>
			<tr>
				<td rowspan="2"><img src="BUTEX.png" width="100px" height="100px" style="align:right"></td>
				<td width="80%">
					<b>
						Bangladesh University of Textiles
							<br>
						B.Sc. in Textile Engineering Admission Test(Session: 2020-2021)
					</b>
				</td>
			</tr>
		</table>
	</div>
	<div class="row center 20px">
		Admit Card
	</div>
	<div class="border">
		<table width="100%">
			<tr>
				<td width="30%">Admission Roll No</td>
				<td width="50%">'.$row["id"].'</td>
				<td rowspan="7"><img src="300x300.jpg" width="150px" height="150px" style="align:right"></td>
			</tr>
			<tr>
				<td >Name</td>
				<td >'.$row["name"].'</td>
			</tr>
			<tr>
				<td >Mobile</td>
				<td >'.$row["mobile"].'</td>
			</tr>
			<tr>
				<td >HSC Roll</td>
				<td > 133534</td>
			</tr>
			<tr>
				<td >HSC Board</td>
				<td >DINAJPUR</td>
			</tr>
			<tr>
				<td >HSC Year</td>
				<td >2020</td>
			</tr>
		</table>
		<table weight="100%">
			<tr>
				<td width="120%"><img src="300x80.jpg" width="300px" height="80px" style="align:right"></td>
				<td width="100%"><img src="300x80.jpg" width="300px" height="80px" style="align:right"></td>
			</tr>
			<tr>
				<td width="120%">Applicant\'s signature</td>
				<td width="100%" class="right">Head teacher\'s signature</td>
			</tr>
		</table>
	</div>
	<div class="row">
	<table width="100%">
			<tr>
				<td width="50%">Date: '.date("d M Y h:i A").'</td>
				<td width="50%"></td>
			<tr>
	</table>
	</div>
	<br>
	<div class="border gray center" width="100%">
		<b>General instructions for applicants<b>
	</div>
	<div class="border gray justify" width="100%">
		<ol>
			<li>
			Bring printed copy of this admit card in the examination hall.
			</li>
		</ol>
	</div>
	<br>
	<div class="row border">
		<table width="100%">
				<tr>
					<td width="90%">©2021, Bangladesh University of Textiles, All Rights Reserved</td>
					<!--<td width="10%"><img src="BUTEX.png" width="100px" height="100px" style="float: right;"></td>-->
				<tr>
		</table>
	</div>';
}else{
	$html='<table id="customers">';
		$html.='<tr></tr>';
			$html.='<tr>
						<td colspan="3">No Data Found</td>
					</tr>';
	$html.='</table>';
}
$mpdf= new \Mpdf\Mpdf([
	'fontdata' => [
		'nikosh'=>[
			'R' => 'Nikosh.ttf',
			'I' => 'Nikosh.ttf',
		],
	],
	'default_font' => 'nikosh'
]);
//$mpdf->setHeader('Left|Center|{PAGENO}');
$mpdf->setTitle("Admit Card of ".$row["name"]);
$mpdf->setAuthor("Dhrubo");
$mpdf->setCreator("Dhrubo");
$stylesheet=file_get_contents('admitstyle.css');
$mpdf->WriteHTML($stylesheet,\Mpdf\HTMLParserMode::HEADER_CSS);
$mpdf->WriteHTML($html,\Mpdf\HTMLParserMode::HTML_BODY);
$file='admit_'.$row["name"].'.pdf';
$mpdf->output($file,'I');

